	<footer id="footer" class="fh5co-bg-color">
		<div class="container">
			<div class="row">
				<div class="col-md-3">
					<div class="copyright">
					</div>
				</div>
				<div class="col-md-6">
					<div class="row">
						<div class="col-md-6">
							<h3>Company</h3>
							<ul class="link">
								<li><a href="home.php">Home Page</a></li>					
								<li><a href="contact.php">Contact Us</a></li>
								<li><a href="services.php">Services</a></li>
								<li><a href="penthouse.php">Penthouse Suite</a></li>					
								<li><a href="master.php">Master Suite</a></li>
								<li><a href="standard.php">Standard Suite</a></li>
							</ul>
						</div>
						<div class="col-md-3">
						</div>
					</div>
				</div>
			</div>
		</div>
	</footer>