	<div id="fh5co-header">
		<header id="fh5co-header-section">
			<div class="container">
				<div class="nav-header">
					<a href="#" class="js-fh5co-nav-toggle fh5co-nav-toggle"><i></i></a>
					<h1 id="fh5co-logo"><a href="home.php">Trivago</a></h1>
					<nav id="fh5co-menu-wrap" role="navigation">
						<ul class="sf-menu" id="fh5co-primary-menu">
							<li><a href="home.php">Home</a></li>
							<li>
								<a class="fh5co-sub-ddown">Suites</a>
								<ul class="fh5co-sub-menu">
								 	<li><a href="penthouse.php">Penthouse Suite</a></li>
								 	<li><a href="master.php">Master Suite</a></li>
									<li><a href="standard.php">Standard Room</a></li> 
								</ul>
							</li>
							<li><a href="services.php">Services</a></li>
							<li><a href="contact.php">Contact</a></li>
						</ul>
					</nav>
				</div>
			</div>
		</header>	
	</div> 