<!DOCTYPE html>
<html class="no-js">
	<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Luxe Hotel</title>
	<link rel="shortcut icon" href="favicon.ico">
	
	<!-- Stylesheets -->
	<!-- Dropdown Menu -->
	<link rel="stylesheet" href="css/superfish.css">
	<!-- Owl Slider -->
	<!-- <link rel="stylesheet" href="css/owl.carousel.css"> -->
	<!-- <link rel="stylesheet" href="css/owl.theme.default.min.css"> -->
	<!-- Date Picker -->
	<link rel="stylesheet" href="css/bootstrap-datepicker.min.css">
	<!-- CS Select -->
	<link rel="stylesheet" href="css/cs-select.css">
	<link rel="stylesheet" href="css/cs-skin-border.css">

	<!-- Themify Icons -->
	<link rel="stylesheet" href="css/themify-icons.css">
	<!-- Flat Icon -->
	<link rel="stylesheet" href="css/flaticon.css">
	<!-- Icomoon -->
	<link rel="stylesheet" href="css/icomoon.css">
	<!-- Flexslider  -->
	<link rel="stylesheet" href="css/flexslider.css">
	
	<!-- Style -->
	<link rel="stylesheet" href="css/style.css">

	<!-- Modernizr JS -->
	<script src="js/modernizr-2.6.2.min.js"></script>
	<!-- FOR IE9 below -->
	<!--[if lt IE 9]>
	<script src="js/respond.min.js"></script>
	<![endif]-->
</head>
<body>
	<div id="fh5co-wrapper">
	<div id="fh5co-page">
	<div id="fh5co-header">
	<?php include 'header.php';?>
	</div>
	<div class="fh5co-parallax" style="background-image: url(images/entrance.jpg);" data-stellar-background-ratio="0.5">
		<div class="overlay"></div>
		<div class="container">
			<div class="row">
				<div class="col-md-12 col-md-offset-0 col-sm-12 col-sm-offset-0 col-xs-12 col-xs-offset-0 text-center fh5co-table">
					<div class="fh5co-intro fh5co-table-cell">
						<h1 class="text-center">Reservations</h1>					
					</div>
				</div>
			</div>
		</div>
	</div>
	<?php	
    if(isset($_POST['submitted'])){
        $dbc = mysqli_connect('localhost', 'root', '');
        mysqli_select_db($dbc, 'hotel');
		$problem = False;
		
        
        if(!empty($_POST['date_start']) && !empty($_POST['date_end']) && !empty($_POST['suite']) && !empty($_POST['name']) && !empty($_POST['email'])){
            $date_start = ($_POST['date_start']);
			$date_end = ($_POST['date_end']);
			$suite = ($_POST['suite']);
			$name = ($_POST['name']);
			$email = ($_POST['email']);
			
		}else{
            $problem = True;
        }
        
        if(!$problem){
			$query = "INSERT INTO reservation(entry_id, check_start, check_end, suite, name, email)
                        VALUES(0, '$date_start', '$date_end', '$suite', '$name', '$email')"; 			
            if(mysqli_query($dbc, $query)){
                print '<script>alert("Reservations Succesful")</script>';
            }
            else{
                print '<p style="color:red;">Could not add the entry because:<br />'.mysqli_error($dbc).'</p>
                        <p>The query was: '.$query.'</p>';

            }
        }             
    }
	?>
	<div class="wrap">
		<div class="container">
		<form action="reservation.php" method="post">
			<div class="row">
				<div id="availability">
					<form action="home.php" method="post">
						<div class="a-col">
							<section>
								<select class="cs-select cs-skin-border" name="suite" required>
									<option value="" disabled selected>Select Suite</option>
									<option value="penthouse suite">Penthouse Suite</option>
									<option value="master suite">Master Suite</option>
									<option value="standard suite">Standard Suite</option>
								</select>
							</section>
						</div>
						<div class="a-col alternate">
							<div class="input-field">
								<label for="date-start">Check In</label>
								<input type="text" class="form-control" id="date-start" name="date_start" required/>
							</div>
						</div>
						<div class="a-col alternate">
							<div class="input-field">
								<label for="date-end">Check Out</label>
								<input type="text" class="form-control" id="date-end" name="date_end" required/>
							</div>
						</div>
						<div class="a-col alternate">
							<div class="form-group">
								<input type="text" class="form-control" placeholder="Mr./Mrs./Ms." name="name" pattern="[A-Za-z]+" required/>
							</div>
						</div>
						<div class="a-col alternate">
							<div class="form-group">
								<input type="email" class="form-control" placeholder="Email" name="email" required>
							</div>
						</div>
						<div class="col-md-12">
							<div class="form-group">
								<input type="submit" name="submitted" value="Book Now" class="btn btn-primary btn-luxe-primary">
							</div>
						</div>
					</form>
				</div>
			</div>		
		</form>
		</div>
	</div>		
	<?php include 'footer.php';?>

	</div>
	<!-- END fh5co-page -->

	</div>
	<!-- END fh5co-wrapper -->
	
	<!-- Javascripts -->
	<script src="js/jquery-2.1.4.min.js"></script>
	<!-- Dropdown Menu -->
	<script src="js/hoverIntent.js"></script>
	<script src="js/superfish.js"></script>
	<!-- Bootstrap -->
	<script src="js/bootstrap.min.js"></script>
	<!-- Waypoints -->
	<script src="js/jquery.waypoints.min.js"></script>
	<!-- Counters -->
	<script src="js/jquery.countTo.js"></script>
	<!-- Stellar Parallax -->
	<script src="js/jquery.stellar.min.js"></script>
	<!-- Owl Slider -->
	<!-- // <script src="js/owl.carousel.min.js"></script> -->
	<!-- Date Picker -->
	<script src="js/bootstrap-datepicker.min.js"></script>
	<!-- CS Select -->
	<script src="js/classie.js"></script>
	<script src="js/selectFx.js"></script>
	<!-- Flexslider -->
	<script src="js/jquery.flexslider-min.js"></script>

	<script src="js/custom.js"></script>

</body>
</html>