<!DOCTYPE html>
<html class="no-js"> 
	<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Penthouse Suite</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<!-- Place favicon.ico and apple-touch-icon.png in the root directory -->
	<link rel="shortcut icon" href="favicon.ico">
	<!-- <link href='https://fonts.googleapis.com/css?family=Lato:400,100,100italic,300,300italic,400italic,700italic,900,700,900italic' rel='stylesheet' type='text/css'> -->

	<!-- Stylesheets -->
	<!-- Dropdown Menu -->
	<link rel="stylesheet" href="css/superfish.css">
	<!-- Owl Slider -->
	<!-- <link rel="stylesheet" href="css/owl.carousel.css"> -->
	<!-- <link rel="stylesheet" href="css/owl.theme.default.min.css"> -->
	<!-- Date Picker -->
	<link rel="stylesheet" href="css/bootstrap-datepicker.min.css">
	<!-- CS Select -->
	<link rel="stylesheet" href="css/cs-select.css">
	<link rel="stylesheet" href="css/cs-skin-border.css">

	<!-- Themify Icons -->
	<link rel="stylesheet" href="css/themify-icons.css">
	<!-- Flat Icon -->
	<link rel="stylesheet" href="css/flaticon.css">
	<!-- Icomoon -->
	<link rel="stylesheet" href="css/icomoon.css">
	<!-- Flexslider  -->
	<link rel="stylesheet" href="css/flexslider.css">
	
	<!-- Style -->
	<link rel="stylesheet" href="css/style.css">

	<!-- Modernizr JS -->
	<script src="js/modernizr-2.6.2.min.js"></script>
	
</head>
<body>
	<div id="fh5co-wrapper">
	<div id="fh5co-page">
	<div id="fh5co-header">
	<?php include 'header.php';?>
	</div>
	<div class="fh5co-parallax" style="background-image: url(images/penthouse.jpg);" data-stellar-background-ratio="0.5">
		<div class="overlay"></div>
		<div class="container">
			<div class="row">
				<div class="col-md-12 col-md-offset-0 col-sm-12 col-sm-offset-0 col-xs-12 col-xs-offset-0 text-center fh5co-table">
					<div class="fh5co-intro fh5co-table-cell">
						<h1 class="text-center">Penthouse Suite</h1>
					</div>
				</div>
			</div>
		</div>
	</div>

	<div id="fh5co-hotel-section">
		<div class="container">
			<div class="row">
				<div class="col-md-6">
					<div class="hotel-content">
						<div class="hotel-grid" style="background-image: url(images/pent_bathroom.jpg);">						
						</div>
						<div class="desc">
							<p>Designed elegantly with a full marble floor tile, a marble tub under a glass ceiling for customers to enjoy their late night bath under the stars
								and a walk-in shower with a steam room.</p>
						</div>
					</div>
				</div>
				<div class="col-md-6">
					<div class="hotel-content">
						<div class="hotel-grid" style="background-image: url(images/pent_meeting.jpeg);">
						</div>
						<div class="desc">
							<p>The penthouse also features an uniquely designed small size meeting room floored with top quality oak wood with a lounge area beside the meeting area.</p>
						</div>
					</div>
				</div>
				<div class="col-md-4">
					<div class="hotel-content">
						<div class="hotel-grid" style="background-image: url(images/pent_livingroom.jpg);">
						</div>
						<div class="desc">
							<p>With a 70 inch flat screen 4k TV, the penthouse suite comes with a large living room to allow maximum comfort.</p>
						</div>
					</div>
				</div>
				<div class="col-md-4">
					<div class="hotel-content">
						<div class="hotel-grid" style="background-image: url(images/pent_bed.jpg);">
						</div>
						<div class="desc">
							<p>The Penthouse Suite comes with a large water bed for maximum comfort and a glamorous views outside.</p>
						</div>
					</div>
				</div>
				<div class="col-md-4">
					<div class="hotel-content">
						<div class="hotel-grid" style="background-image: url(images/pent_pool.jpg);">
						</div>
						<div class="desc">
							<p>The Penthouse Suite also provides a private access to the open air rooftop pool with a spectacular view</p>
						</div>
					</div>
				</div>
			</div>
		</div>
		
	</div>
	<?php include 'footer.php';?>

	</div>
	<!-- END page -->

	</div>
	<!-- END wrapper -->
	
	<!-- Javascripts -->
	<script src="js/jquery-2.1.4.min.js"></script>
	<!-- Dropdown Menu -->
	<script src="js/hoverIntent.js"></script>
	<script src="js/superfish.js"></script>
	<!-- Bootstrap -->
	<script src="js/bootstrap.min.js"></script>
	<!-- Waypoints -->
	<script src="js/jquery.waypoints.min.js"></script>
	<!-- Counters -->
	<script src="js/jquery.countTo.js"></script>
	<!-- Stellar Parallax -->
	<script src="js/jquery.stellar.min.js"></script>
	<!-- Owl Slider -->
	<!-- // <script src="js/owl.carousel.min.js"></script> -->
	<!-- Date Picker -->
	<script src="js/bootstrap-datepicker.min.js"></script>
	<!-- CS Select -->
	<script src="js/classie.js"></script>
	<script src="js/selectFx.js"></script>
	<!-- Flexslider -->
	<script src="js/jquery.flexslider-min.js"></script>

	<script src="js/custom.js"></script>

</body>
</html>